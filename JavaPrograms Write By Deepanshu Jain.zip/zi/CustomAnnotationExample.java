import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
@interface MyAnnotation {
    String value();
}

@MyAnnotation(value = "This is a custom annotation")
public class CustomAnnotationExample {
    public static void main(String[] args) {
        CustomAnnotationExample obj = new CustomAnnotationExample();
        Class<?> c = obj.getClass();
        MyAnnotation annotation = c.getAnnotation(MyAnnotation.class);
        System.out.println("Value: " + annotation.value());
    }
}

