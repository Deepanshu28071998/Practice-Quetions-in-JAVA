public class AssertionExample {
    public static void main(String[] args) {
        int age = 15;
        assert age >= 18 : "Age is less than 18";
        System.out.println("Age is " + age);
    }
}

