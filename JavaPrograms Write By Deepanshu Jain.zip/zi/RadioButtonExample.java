import javax.swing.*;
import java.awt.event.*;

public class RadioButtonExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("RadioButton Example");
        JRadioButton r1 = new JRadioButton("A) Yes");
        JRadioButton r2 = new JRadioButton("B) No");

        r1.setBounds(75, 50, 100, 30);
        r2.setBounds(75, 100, 100, 30);

        ButtonGroup bg = new ButtonGroup();
        bg.add(r1);
        bg.add(r2);

        JButton b = new JButton("Click");
        b.setBounds(75, 150, 100, 30);
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (r1.isSelected()) {
                    JOptionPane.showMessageDialog(frame, "You selected Yes.");
                }
                if (r2.isSelected()) {
                    JOptionPane.showMessageDialog(frame, "You selected No.");
                }
            }
        });

        frame.add(r1);
        frame.add(r2);
        frame.add(b);

        frame.setSize(300, 300);
        frame.setLayout(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

