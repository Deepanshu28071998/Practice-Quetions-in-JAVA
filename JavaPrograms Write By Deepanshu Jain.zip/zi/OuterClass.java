public class OuterClass {
    static class StaticNestedClass {
        void display() {
            System.out.println("Inside static nested class.");
        }
    }

    public static void main(String[] args) {
        OuterClass.StaticNestedClass nestedObject = new OuterClass.StaticNestedClass();
        nestedObject.display();
    }
}

