public class ThisKeywordExample {
    int num;

    ThisKeywordExample(int num) {
        this.num = num;
    }

    void display() {
        System.out.println("Value of num is: " + this.num);
    }

    public static void main(String[] args) {
        ThisKeywordExample obj = new ThisKeywordExample(100);
        obj.display();
    }
}

