public class BalanceCheck {
    public void checkBalance(double balance) {
        if (balance < 1000) {
            System.out.println("Balance is low");
        } else {
            System.out.println("Sufficient balance");
        }
    }

    public static void main(String[] args) {
        BalanceCheck bc = new BalanceCheck();
        bc.checkBalance(950.00);
        bc.checkBalance(1500.00);
    }
}

