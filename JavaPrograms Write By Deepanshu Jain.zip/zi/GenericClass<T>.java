class GenericClass<T> {
    private T value;

    public void setValue(T value) {
        this.value = value;
    }

    public T getValue() {
        return value;
    }

    public static void main(String[] args) {
        GenericClass<Integer> intObj = new GenericClass<>();
        intObj.setValue(10);
        System.out.println("Integer Value: " + intObj.getValue());

        GenericClass<String> stringObj = new GenericClass<>();
        stringObj.setValue("Hello");
        System.out.println("String Value: " + stringObj.getValue());
    }
}

