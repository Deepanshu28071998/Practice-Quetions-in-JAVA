public class AutoboxingExample {
    public static void main(String[] args) {
        int i = 10;
        Integer intObj = i; // Autoboxing
        System.out.println("Integer object: " + intObj);
    }
}

