// File: mypackage/MyClass.java
package mypackage;

public class MyClass {
    public void display() {
        System.out.println("This is a user-defined package.");
    }
}

// File: Main.java
import mypackage.MyClass;

public class Main {
    public static void main(String[] args) {
        MyClass obj = new MyClass();
        obj.display();
    }
}

