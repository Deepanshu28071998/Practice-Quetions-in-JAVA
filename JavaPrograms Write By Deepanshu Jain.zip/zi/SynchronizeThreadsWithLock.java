import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class SharedResource {
    private Lock lock = new ReentrantLock();

    public void accessResource() {
        lock.lock();
        try {
            System.out.println(Thread.currentThread().getName() + " is accessing the resource");
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }
}

class Worker extends Thread {
    private SharedResource resource;

    public Worker(SharedResource resource) {
        this.resource = resource;
    }

    public void run() {
        resource.accessResource();
    }
}

public class SynchronizeThreadsWithLock {
    public static void main(String[] args) {
        SharedResource resource = new SharedResource();
        Worker t1 = new Worker(resource);
        Worker t2 = new Worker(resource);
        t1.start();
        t2.start();
    }
}

