public class StaticFieldExample {
    static int count = 0;

    public StaticFieldExample() {
        count++;
    }

    public static void main(String[] args) {
        StaticFieldExample obj1 = new StaticFieldExample();
        StaticFieldExample obj2 = new StaticFieldExample();
        StaticFieldExample obj3 = new StaticFieldExample();

        System.out.println("Number of objects created: " + StaticFieldExample.count);
    }
}

