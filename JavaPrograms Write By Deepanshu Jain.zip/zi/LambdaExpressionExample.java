interface MyInterface {
    void display();
}

public class LambdaExpressionExample {
    public static void main(String[] args) {
        MyInterface myInterface = () -> {
            System.out.println("Lambda expression without parameter");
        };
        myInterface.display();
    }
}

