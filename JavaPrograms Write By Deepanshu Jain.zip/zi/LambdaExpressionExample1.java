interface MyInterface {
    void add(int a, int b);
}

public class LambdaExpressionExample1 {
    public static void main(String[] args) {
        MyInterface myInterface = (a, b) -> {
            System.out.println("Sum: " + (a + b));
        };
        myInterface.add(10, 20);
    }
}

