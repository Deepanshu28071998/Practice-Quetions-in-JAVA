public class UnboxingExample {
    public static void main(String[] args) {
        
        Integer integerObj = new Integer(10);
        
        
        int num = integerObj;
        
        
        System.out.println("Value of num (after unboxing): " + num);

        
        Double doubleObj = new Double(15.5);
        double doubleNum = doubleObj;
        System.out.println("Value of doubleNum (after unboxing): " + doubleNum);

        Boolean boolObj = new Boolean(true);
        boolean bool = boolObj;
        System.out.println("Value of bool (after unboxing): " + bool);
    }
}

