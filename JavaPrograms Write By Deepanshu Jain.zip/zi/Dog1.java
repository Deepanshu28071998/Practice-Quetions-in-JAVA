class Animal {
    Animal() {
        System.out.println("Animal is created");
    }
}

class Dog1 extends Animal {
    Dog1() {
        System.out.println("Dog is created");
    }

    public static void main(String[] args) {
        Dog1 d = new Dog1();
    }
}

