public class GarbageCollectionExample {
    protected void finalize() {
        System.out.println("Garbage collected");
    }

    public static void main(String[] args) {
        GarbageCollectionExample obj = new GarbageCollectionExample();
        obj = null;
        System.gc();
    }
}

