import java.awt.*;
import java.awt.event.*;

public class ButtonEventHandling {
    public static void main(String[] args) {
        Frame frame = new Frame("Button Event Handling");

        Button b = new Button("OK");
        b.setBounds(50, 100, 60, 30);

        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("OK Button Clicked");
            }
        });

        frame.add(b);

        frame.setSize(200, 200);
        frame.setLayout(null);
        frame.setVisible(true);

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent windowEvent) {
                System.exit(0);
            }
        });
    }
}

