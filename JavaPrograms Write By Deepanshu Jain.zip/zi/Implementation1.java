class OuterClassWithInterface {
    interface NestedInterface {
        void nestedMethod();
    }
}

class Implementation1 implements OuterClassWithInterface.NestedInterface {
    public void nestedMethod() {
        System.out.println("Nested interface inside class method");
    }

    public static void main(String[] args) {
        Implementation1 impl = new Implementation1();
        impl.nestedMethod();
    }
}

