interface OuterInterface {
    void outerMethod();

    interface NestedInterface {
        void nestedMethod();
    }
}

class Implementation implements OuterInterface.NestedInterface {
    public void nestedMethod() {
        System.out.println("Nested interface method");
    }

    public static void main(String[] args) {
        Implementation impl = new Implementation();
        impl.nestedMethod();
    }
}

