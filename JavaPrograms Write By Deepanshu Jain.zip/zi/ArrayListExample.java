import java.util.ArrayList;

public class ArrayListExample {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();

        // Add elements
        list.add("A");
        list.add("B");
        list.add("C");

        // Retrieve elements
        System.out.println("Element at index 1: " + list.get(1));

        // Remove elements
        list.remove("B");

        System.out.println("ArrayList after removal: " + list);
    }
}

