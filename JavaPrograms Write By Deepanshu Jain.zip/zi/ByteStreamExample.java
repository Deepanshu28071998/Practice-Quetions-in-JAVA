import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteStreamExample {
    public static void main(String[] args) {
        try (FileInputStream fis1 = new FileInputStream("file1.txt");
             FileInputStream fis2 = new FileInputStream("file2.txt");
             FileOutputStream fos = new FileOutputStream("file3.txt")) {

            int c;
            while ((c = fis1.read()) != -1) {
                fos.write(c);
            }
            while ((c = fis2.read()) != -1) {
                fos.write(c);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

