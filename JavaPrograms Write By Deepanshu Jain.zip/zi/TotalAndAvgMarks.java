public class TotalAndAvgMarks {
    public static void main(String[] args) {
        if (args.length < 4) {
            System.out.println("Please provide name and three marks.");
            return;
        }
        String name = args[0];
        int marks1 = Integer.parseInt(args[1]);
        int marks2 = Integer.parseInt(args[2]);
        int marks3 = Integer.parseInt(args[3]);

        int total = marks1 + marks2 + marks3;
        double average = total / 3.0;

        System.out.println("Name: " + name);
        System.out.println("Total Marks: " + total);
        System.out.println("Average Marks: " + average);
    }
}

